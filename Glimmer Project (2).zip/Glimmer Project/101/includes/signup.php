<?php
	include_once 'header.php';
	?>

	<section class="signup-form">
		<h1>Signup</h1>
		<div class="signup-form-form">
		<form action="signup.inc.php" method="post">
		<input type="text" name="uid" placeholder="Username">
		<input type="text" name="mail" placeholder="E-mail">
		<input type="password" name="pwd-repeat" placeholder="Repeat password">
		<button type="submit" name="signup-submit">Signup</button>

		</form>
	</section>
</div>

<?php
	include_once 'footer.php';
?>
